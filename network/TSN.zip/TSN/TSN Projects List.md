# P802.1AS-Revision:
- IEEE Standard for Local and Metropolitan Area Networks
  LANおよびMAN用のIEEE規格
- Timing and Synchronization for Time-Sensitive Applications in Bridged Local Area Networks
  ブリッジ接続されたLANにおける時間調整および同期
- Status: PAR approved, technical development in process, task group ballots
  状況: 標準は承認済み、技術開発中、タスクグループ採決

 通常のネットワーク使用の他、機器の追加、削除によるネットワーク構成の変更に対応している。
 有名な時刻同期の規格であるUTCやTAIは、本規格には含まれないが、却下はされない。

# P802.1Qbu:
- Standard for Local and metropolitan area networks
  LANおよびMAN用のIEEE規格
- Media Access Control (MAC) Bridges and Virtual Bridged Local Area Networks Amendment: Frame Preemption
  MACブリッジおよび仮想ブリッジ接続されたLANの改正：フレームプリエンプション
- Status: PAR approved, technical development in process, working group ballots



# P802.1Qbv:
- Standard for Local and metropolitan area networks
  LANおよびMAN用のIEEE規格
- Media Access Control (MAC) Bridges and Virtual Bridged Local Area Networks Amendment: Enhancements for Scheduled Traffic
- Status: PAR approved, technical development in process, working group ballots

# P802.1Qcc:
- Standard for Local and metropolitan area networks
  LANおよびMAN用のIEEE規格
- Media Access Control (MAC) Bridges and Virtual Bridged Local Area Networks Amendment: Stream Reservation Protocol (SRP) Enhancements and Performance Improvements
- Status: PAR approved, technical development in process, task group ballots

# P802.1CB:
- Standard for Local and Metropolitan Area Networks
  LANおよびMAN用のIEEE規格
- Frame Replication and Elimination for Reliability
- Status: PAR approved, technical development in process, task group ballots

# P802.1Qch:
- Standard for Local and metropolitan area networks
  LANおよびMAN用のIEEE規格
- Media Access Control (MAC) Bridges and Virtual Bridged Local Area Networks Amendment: Cyclic Queuing and Forwarding
- Status: PAR approved, technical development in process, no drafts

# P802.1Qci:
- Standard for Local and metropolitan area networks
  LANおよびMAN用のIEEE規格
- Bridges and Bridged Networks Amendment: Per-Stream Filtering and Policing
- Status: PAR approved, technical development in process, no drafts

_aaaa_
- GMの比較方法
- フォローメッセージ
- 予約に優先度あるの？
- Talkerから予約できるの？

